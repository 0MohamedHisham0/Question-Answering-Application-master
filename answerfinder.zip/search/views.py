import os, io
import errno
import urllib
import urllib.request
from time import sleep
import pandas as pd
from urllib.request import urlopen, Request
from django.shortcuts import render
from django.http import JsonResponse
from bs4 import BeautifulSoup
from googlesearch import search
from cdqa.utils.converters import pdf_converter
from cdqa.utils.filters import filter_paragraphs
from cdqa.utils.download import download_model, download_bnpp_data
from cdqa.pipeline.cdqa_sklearn import QAPipeline
from cdqa.utils.download import download_model
from .models import Upload
from rest_framework.decorators import api_view
from rest_framework.response import Response



@api_view(['GET','POST'])
def search_view(request):
    print("before post ==========")
    if request.POST:
        download_model(model='bert-squad_1.1', dir='./models')
        a = Upload.objects.all()
        x = a.first()
        print("=============================")
        p = x.file
        print(p)
        #question = request.POST.get('question')
        #question = question.encode("utf-8")
        question = "What is the cold dark misty world of the dead, ruled by the goddess Hel?"
        print(question)
        #for idx, url in enumerate(search(question, tld="com", num=10, stop=None, pause=2)):
         #   crawl_result(url, idx)
        # change path to pdfs folder
        df = pdf_converter(directory_path='./pdf')
        #print("after data frame", df)
        cdqa_pipeline = QAPipeline(reader='models/bert_qa.joblib', max_df=1.0)
        print("first pipeline")
        cdqa_pipeline.fit_retriever(df=df)
        print("second pipeline")
        prediction = cdqa_pipeline.predict(question)
        print("s3ody##################################################################################################################################")
        data = {
        'answer': prediction[0]
        }
        answerlist = {
            'query': question,
            'answer': prediction[0],
            'title': prediction[1],
            'paragraph': prediction[2]
        }
        print("finish", data)
        print('query: {}'.format(question))
        print('answer: {}'.format(prediction[0]))
        print('title: {}'.format(prediction[1]))
        print('paragraph: {}'.format(prediction[2]))
        print()
        return Response(answerlist)
        #return JsonResponse(data)
    return render(request, 'search.html')
   

def crawl_result(url, idx):
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        html = urlopen(req).read()
        bs = BeautifulSoup(html, 'html.parser')
        # change path to pdfs folder
        filename = "/path/to/pdfs/" + str(idx) + ".pdf"
        if not os.path.exists(os.path.dirname(filename)):
            try:
                os.makedirs(os.path.dirname(filename))
            except OSError as exc: # Guard against race condition
                if exc.errno != errno.EEXIST:
                    raise
        with open(filename, 'w') as f:
            for line in bs.find_all('p')[:5]:
                f.write(line.text + '\n')
    except (urllib.error.HTTPError, AttributeError) as e:
        pass


