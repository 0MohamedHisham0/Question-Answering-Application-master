from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('api-auth/', include('rest_framework.urls')),
    path('search/', views.search_view, name="search"),
]